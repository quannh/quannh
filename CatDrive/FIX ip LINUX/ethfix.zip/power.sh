mdio eth0 22 1
mdio eth0 26
mdio eth0 22 0
